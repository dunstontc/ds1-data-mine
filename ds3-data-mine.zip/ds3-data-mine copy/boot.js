require('coffee-script');
require('coffee-script/register');
require('any-promise/register/bluebird');
require('./index.coffee');
